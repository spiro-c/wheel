# -*- coding:utf-8 -*-
from __future__ import absolute_import
from .version import version as __version__  # noqa
from ._rtmidi import *  # noqa
from ._rtmidi import __doc__  # noqa
del absolute_import
